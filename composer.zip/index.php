<?php
// Kullanıcıyı "login.php" sayfasına yönlendir
header("Location: login.php");
exit();
?>